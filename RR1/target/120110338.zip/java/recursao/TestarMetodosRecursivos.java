package recursao;

public class TestarMetodosRecursivos {
	public static void main(String[] args) {
		MetodosRecursivos mr = new MetodosRecursivos();
		System.out.println(mr.progressaoGeometrica(2, 3, 4));
	}
}
